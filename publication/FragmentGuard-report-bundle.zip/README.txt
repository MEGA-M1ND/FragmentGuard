FragmentGuard — final project report

Open publication/FragmentGuard-final-report.pdf or publication/index.html.
Editable write-up: docs/final_report.md. Submission summary: publication/submission.md.
Code/raw evidence: https://github.com/MEGA-M1ND/FragmentGuard
Publication snapshot: final-project-report-2026-10-28.
The four-case live successor was not run and is outside the completed study.
