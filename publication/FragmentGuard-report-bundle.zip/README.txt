FragmentGuard — final project report, presentation revision 2

Open publication/FragmentGuard-final-report.pdf or publication/index.html.
Editable write-up: docs/final_report.md. Submission summary: publication/submission.md.
Presentation: publication/presentation-notes.md.
Code/raw evidence: https://github.com/MEGA-M1ND/FragmentGuard
Publication snapshot: final-project-report-2026-10-28-v2.
The four-case live successor was not run and is outside the completed study.
